<?php

class wisata_model extends CI_Model{
    public function getWisata($id= null){
        if($id === null){ 
            return $this->db->get('wisata')->result_array();
        }
        else{
            return $this->db->get_where('wisata', ['id'=>$id])->result_array();
        }
      
    }
    public function getKuliner($id= null){
        if($id === null){ 
            return $this->db->get('kuliner')->result_array();
        }
        else{
            return $this->db->get_where('kuliner', ['id'=>$id])->result_array();
        }
      
    }
}