<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class kuliner extends REST_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('wisata_model', 'kuliner');
    } 

    public function index_get(){
        $id = $this->get('id');
        if($id === null){
            $kuliner = $this->kuliner->getKuliner();
        } else{
            $kuliner = $this->kuliner->getKuliner($id);
        }
        
        if($kuliner){
            $this->set_response([
                'status' => true,
                'data' => $kuliner
            ], REST_Controller::HTTP_OK);
        }
        else{
            $this->set_response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}

?>