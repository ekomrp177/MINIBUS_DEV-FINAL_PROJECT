<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class wisata extends REST_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('wisata_model', 'wisata');
    } 

    public function index_get(){
        $id = $this->get('id');
        if($id === null){
            $wisata = $this->wisata->getWisata();
        } else{
            $wisata = $this->wisata->getWisata($id);
        }
        
        if($wisata){
            $this->set_response([
                'status' => true,
                'data' => $wisata
            ], REST_Controller::HTTP_OK);
        }
        else{
            $this->set_response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}

?>